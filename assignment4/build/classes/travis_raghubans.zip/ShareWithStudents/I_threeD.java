/*

This is an interface file to compute volume of a 3D shape object.
*/
package ShareWithStudents;

public interface I_threeD {
    
    float computeVolume();
    
}