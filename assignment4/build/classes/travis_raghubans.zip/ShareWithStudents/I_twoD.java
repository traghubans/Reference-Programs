/*This is an interface file to compute the area and the perimeter of a 2D shape object.
*/
package ShareWithStudents;

public interface I_twoD {
    
    float computeArea();
    float computePerimeter();
    
}